# User Guide

  - [Creating a Virtual Cloud Network](./createvcn.md)
  - [Reusing as a Terraform module](./reusemodule.md)
  - [Virtual Cloud Network Gateways](././gateways.md)
  - [Configuring routing rules](./routerules.md)
  - [Using Resource Manager](./resourcemanager.md)